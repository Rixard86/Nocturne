package com.nocturne.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

/**
 * Bridge between the web UI and the native AudioCaptureService.
 *
 * JS methods:
 *   start({ sensitivity })      -> begins the foreground service + capture
 *   stop()                      -> stops the service
 *   setSensitivity({ ratio })   -> updates detection ratio live
 *   isRunning()                 -> { running }
 *
 * Events pushed to JS (addListener):
 *   nocturneCalibrating { amp, secondsLeft }
 *   nocturneState       { state, amp, snoreCount, pauseCount, baseline }
 *   nocturneLevel       { level, snoring, elapsed }
 *   nocturneSample      { t, amp, level }
 *   nocturneSnore       { t, dur, level, count }
 *   nocturnePause       { t, dur, count }
 *   nocturneError       { message }
 */
@CapacitorPlugin(name = "Nocturne")
class NocturnePlugin : Plugin() {

    companion object {
        private var instance: NocturnePlugin? = null

        private fun emit(event: String, data: JSObject) {
            instance?.notifyListeners(event, data)
        }

        fun emitCalibrating(amp: Double, secondsLeft: Double) {
            emit("nocturneCalibrating", JSObject().put("amp", amp).put("secondsLeft", secondsLeft))
        }
        fun emitState(state: String, amp: Double, snoreCount: Int, pauseCount: Int, baseline: Double) {
            emit("nocturneState", JSObject()
                .put("state", state).put("amp", amp)
                .put("snoreCount", snoreCount).put("pauseCount", pauseCount)
                .put("baseline", baseline))
        }
        fun emitLevel(level: Int, snoring: Boolean, elapsed: Double) {
            emit("nocturneLevel", JSObject().put("level", level).put("snoring", snoring).put("elapsed", elapsed))
        }
        fun emitSample(t: Double, amp: Double, level: Int) {
            emit("nocturneSample", JSObject().put("t", t).put("amp", amp).put("level", level))
        }
        fun emitSnore(t: Double, dur: Double, level: Int, count: Int, clipPath: String = "") {
            emit("nocturneSnore", JSObject().put("t", t).put("dur", dur).put("level", level).put("count", count).put("clip", clipPath))
        }
        fun emitPause(t: Double, dur: Double, count: Int) {
            emit("nocturnePause", JSObject().put("t", t).put("dur", dur).put("count", count))
        }
        fun emitError(message: String) {
            emit("nocturneError", JSObject().put("message", message))
        }
        fun emitAlarm() {
            emit("nocturneAlarm", JSObject().put("fired", true))
        }
    }

    override fun load() {
        instance = this
    }

    private fun hasMicPermission(): Boolean {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
    }

    @PluginMethod
    fun start(call: PluginCall) {
        if (!hasMicPermission()) {
            call.reject("microphone-permission-denied")
            return
        }
        val ratio = call.getDouble("sensitivity") ?: 2.0
        AudioCaptureService.sensitivityRatio = ratio
        val intent = Intent(context, AudioCaptureService::class.java)
        intent.putExtra(AudioCaptureService.EXTRA_SENSITIVITY, ratio)
        // smart alarm parameters (optional)
        if (call.getBoolean("alarmEnabled", false) == true) {
            intent.putExtra(AudioCaptureService.EXTRA_ALARM_ENABLED, true)
            intent.putExtra(AudioCaptureService.EXTRA_ALARM_TIME, call.getString("alarmTime") ?: "07:00")
            intent.putExtra(AudioCaptureService.EXTRA_ALARM_WINDOW, call.getInt("alarmWindowMin", 30))
        }
        // Must be started while the app is foreground (user tapped Record) — allowed.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        call.resolve(JSObject().put("started", true))
    }

    @PluginMethod
    fun stop(call: PluginCall) {
        val intent = Intent(context, AudioCaptureService::class.java)
        context.stopService(intent)
        call.resolve(JSObject().put("stopped", true))
    }

    @PluginMethod
    fun setSensitivity(call: PluginCall) {
        val ratio = call.getDouble("ratio") ?: 2.0
        AudioCaptureService.sensitivityRatio = ratio
        call.resolve()
    }

    @PluginMethod
    fun isRunning(call: PluginCall) {
        call.resolve(JSObject().put("running", AudioCaptureService.running))
    }
}
