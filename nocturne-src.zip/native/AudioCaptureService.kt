package com.nocturne.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Foreground service that records audio via AudioRecord and runs snore / breathing-pause
 * detection natively, so it keeps working with the screen off. Detection mirrors the
 * JavaScript logic: an initial room-baseline calibration, an adaptive quiet floor, a
 * sensitivity-driven ratio for snore events, and a loud-then-long-silence pause flag.
 *
 * Results are pushed to the JS layer through NocturnePlugin's static event bridge.
 */
class AudioCaptureService : Service() {

    companion object {
        const val CHANNEL_ID = "nocturne_capture"
        const val NOTIF_ID = 4711
        const val EXTRA_SENSITIVITY = "sensitivity"
        @Volatile var running = false
        @Volatile var sensitivityRatio = 2.0   // updated live from the plugin
    }

    private var thread: Thread? = null
    @Volatile private var stopRequested = false

    // detection state
    private var baseline = 0.012
    private var startMs = 0L
    private var calibrating = true
    private var calibStart = 0L
    private val calibSamples = ArrayList<Double>()
    private var inSnore = false
    private var snoreStartMs = 0L
    private var quietSince = 0L
    private var loudSince = 0L
    private var pauseLogged = false
    private var lastSampleMs = 0L
    private var snoreCount = 0
    private var pauseCount = 0

    private val calibrationMs = 4000L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        sensitivityRatio = intent?.getDoubleExtra(EXTRA_SENSITIVITY, 2.0) ?: 2.0
        startForegroundWithNotification()
        if (!running) {
            running = true
            stopRequested = false
            thread = Thread { captureLoop() }.also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopRequested = true
        running = false
        try { thread?.join(500) } catch (_: InterruptedException) {}
        super.onDestroy()
    }

    private fun startForegroundWithNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "Sleep monitoring",
                NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            nm.createNotificationChannel(ch)
        }
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Nocturne is listening")
            .setContentText("Monitoring your sleep for snoring and pauses")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun captureLoop() {
        val sampleRate = 44100
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufSize = max(minBuf, sampleRate / 10) // ~100ms chunks
        val recorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufSize
            )
        } catch (e: SecurityException) {
            NocturnePlugin.emitError("Microphone permission denied")
            stopSelf(); return
        }

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            NocturnePlugin.emitError("AudioRecord failed to initialize")
            stopSelf(); return
        }

        val buffer = ShortArray(bufSize)
        startMs = System.currentTimeMillis()
        calibStart = startMs
        calibrating = true
        quietSince = 0L

        recorder.startRecording()
        NocturnePlugin.emitState("calibrating", 0.0, 0, 0, 0.0)

        while (!stopRequested) {
            val read = recorder.read(buffer, 0, buffer.size)
            if (read <= 0) continue
            val amp = rms(buffer, read)
            val now = System.currentTimeMillis()

            if (calibrating) {
                calibSamples.add(amp)
                val leftSec = max(0L, calibrationMs - (now - calibStart)) / 1000.0
                NocturnePlugin.emitCalibrating(amp, leftSec)
                if (now - calibStart >= calibrationMs) {
                    val sorted = calibSamples.sorted()
                    val med = if (sorted.isEmpty()) 0.012 else sorted[sorted.size / 2]
                    baseline = max(0.004, med)
                    calibrating = false
                    quietSince = now
                    NocturnePlugin.emitState("listening", amp, snoreCount, pauseCount, baseline)
                }
                continue
            }

            // adaptive quiet floor
            if (amp < baseline * 1.4) baseline = baseline * 0.995 + amp * 0.005
            val ratio = amp / max(baseline, 0.0001)
            val level = soundLevel(amp)
            val elapsed = (now - startMs) / 1000.0

            // downsampled ~1s sample for the timeline
            if (lastSampleMs == 0L || now - lastSampleMs > 1000) {
                lastSampleMs = now
                NocturnePlugin.emitSample(elapsed, amp, level)
            }

            val snoreRatio = sensitivityRatio
            if (ratio > snoreRatio) {
                if (!inSnore) { inSnore = true; snoreStartMs = now }
                loudSince = now; quietSince = 0
            } else {
                if (inSnore) {
                    val durSec = (now - snoreStartMs) / 1000.0
                    if (durSec > 0.35) {
                        snoreCount++
                        NocturnePlugin.emitSnore((snoreStartMs - startMs) / 1000.0, durSec, level, snoreCount)
                    }
                    inSnore = false
                }
                if (quietSince == 0L) quietSince = now
            }

            // pause pattern: loud stretch then extended near-silence gap
            if (quietSince != 0L && loudSince != 0L && quietSince > loudSince) {
                val gap = (now - quietSince) / 1000.0
                if (gap > 9 && !pauseLogged) {
                    pauseCount++
                    NocturnePlugin.emitPause((quietSince - startMs) / 1000.0, gap, pauseCount)
                    pauseLogged = true
                }
            }
            if (quietSince != 0L && (now - quietSince) / 1000.0 < 9) pauseLogged = false

            NocturnePlugin.emitLevel(level, ratio > snoreRatio, elapsed)
        }

        try { recorder.stop() } catch (_: Exception) {}
        recorder.release()
    }

    private fun rms(buf: ShortArray, len: Int): Double {
        var sum = 0.0
        for (i in 0 until len) {
            val v = buf[i] / 32768.0
            sum += v * v
        }
        return sqrt(sum / len)
    }

    private fun soundLevel(amp: Double): Int {
        val b = if (baseline > 0) baseline else 0.01
        val ratio = max(1.0, amp / b)
        val lvl = log2(ratio) / log2(14.0) * 100.0
        return max(0.0, min(100.0, lvl)).toInt()
    }
}
