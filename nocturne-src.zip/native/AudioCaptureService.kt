package com.nocturne.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Calendar
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Foreground service that records audio via AudioRecord and runs snore / breathing-pause
 * detection natively, so it keeps working with the screen off. Detection mirrors the
 * JavaScript logic: an initial room-baseline calibration, an adaptive quiet floor, a
 * sensitivity-driven ratio for snore events, and a loud-then-long-silence pause flag.
 *
 * Results are pushed to the JS layer through NocturnePlugin's static event bridge.
 */
class AudioCaptureService : Service() {

    companion object {
        const val CHANNEL_ID = "nocturne_capture"
        const val ALARM_CHANNEL_ID = "nocturne_alarm"
        const val NOTIF_ID = 4711
        const val ALARM_NOTIF_ID = 4712
        const val EXTRA_SENSITIVITY = "sensitivity"
        const val EXTRA_ALARM_ENABLED = "alarm_enabled"
        const val EXTRA_ALARM_TIME = "alarm_time"
        const val EXTRA_ALARM_WINDOW = "alarm_window"
        @Volatile var running = false
        @Volatile var sensitivityRatio = 2.0   // updated live from the plugin
    }

    private var thread: Thread? = null
    @Volatile private var stopRequested = false

    // detection state
    private var baseline = 0.012
    private var startMs = 0L
    private var calibrating = true
    private var calibStart = 0L
    private val calibSamples = ArrayList<Double>()
    // open continuous-snore episode being merged
    private var epActive = false
    private var epStartMs = 0L
    private var epLastActiveMs = 0L
    private var epPeak = 0
    // silence-based pause tracking (apnea = true silence after a snore episode)
    private var silentSinceMs = 0L
    private var lastEpLoudMs = 0L
    private var lastEpDurSec = 0.0
    private val minEpisodePeak = 20   // must at some point reach ~2x the room floor to be a snore

    // acoustic classification (snore / movement / other) of each episode
    private val epClf = AcousticFeatures.EpisodeClassifier()
    private val frameBuf = ArrayList<Double>(AcousticFeatures.FRAME_FFT * 3)
    private val analysisFrame = DoubleArray(AcousticFeatures.FRAME_FFT)
    private val frameFeat = AcousticFeatures.FrameFeatures()
    private var decimRate = 44100 / AcousticFeatures.DECIM_FACTOR
    private var movementCount = 0
    private var otherCount = 0
    private var lastSampleMs = 0L
    private var snoreCount = 0
    private var pauseCount = 0

    private val calibrationMs = 4000L
    private val snoreMergeGapMs = 4000L   // quiet allowed inside one continuous episode

    // audio clip capture for the current episode (real snore audio for playback)
    private var epClip: ArrayList<Short>? = null
    private var clipSampleRate = 44100
    private val clipMaxSamples get() = clipSampleRate * 10  // cap clip at ~10s
    private var clipsDir: File? = null

    // smart alarm
    private var alarmEnabled = false
    private var alarmDeadlineMs = 0L      // absolute time by which we must wake
    private var alarmWindowStartMs = 0L   // earliest time we may wake at a light moment
    private var alarmFired = false
    // recent level history for a light-sleep decision (short-window restlessness)
    private val recentLevels = ArrayDeque<Int>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        sensitivityRatio = intent?.getDoubleExtra(EXTRA_SENSITIVITY, 2.0) ?: 2.0
        // parse smart-alarm config
        alarmEnabled = intent?.getBooleanExtra(EXTRA_ALARM_ENABLED, false) ?: false
        if (alarmEnabled) {
            val hhmm = intent?.getStringExtra(EXTRA_ALARM_TIME) ?: "07:00"
            val windowMin = intent?.getIntExtra(EXTRA_ALARM_WINDOW, 30) ?: 30
            computeAlarmWindow(hhmm, windowMin)
            alarmFired = false
        }
        startForegroundWithNotification()
        if (!running) {
            running = true
            stopRequested = false
            thread = Thread { captureLoop() }.also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopRequested = true
        running = false
        try { thread?.join(500) } catch (_: InterruptedException) {}
        super.onDestroy()
    }

    private fun startForegroundWithNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "Sleep monitoring",
                NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            nm.createNotificationChannel(ch)
        }
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Nocturne is listening")
            .setContentText("Monitoring your sleep for snoring and pauses")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun captureLoop() {
        val sampleRate = 44100
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufSize = max(minBuf, sampleRate / 10) // ~100ms chunks
        val recorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufSize
            )
        } catch (e: SecurityException) {
            NocturnePlugin.emitError("Microphone permission denied")
            stopSelf(); return
        }

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            NocturnePlugin.emitError("AudioRecord failed to initialize")
            stopSelf(); return
        }

        val buffer = ShortArray(bufSize)
        startMs = System.currentTimeMillis()
        calibStart = startMs
        calibrating = true
        clipSampleRate = sampleRate
        clipsDir = File(cacheDir, "snore_clips").apply { mkdirs() }

        recorder.startRecording()
        NocturnePlugin.emitState("calibrating", 0.0, 0, 0, 0.0)

        while (!stopRequested) {
            val read = recorder.read(buffer, 0, buffer.size)
            if (read <= 0) continue
            val amp = rms(buffer, read)
            val now = System.currentTimeMillis()

            if (calibrating) {
                calibSamples.add(amp)
                val leftSec = max(0L, calibrationMs - (now - calibStart)) / 1000.0
                NocturnePlugin.emitCalibrating(amp, leftSec)
                if (now - calibStart >= calibrationMs) {
                    val sorted = calibSamples.sorted()
                    val med = if (sorted.isEmpty()) 0.012 else sorted[sorted.size / 2]
                    baseline = max(0.004, med)
                    calibrating = false
                    NocturnePlugin.emitState("listening", amp, snoreCount, pauseCount, baseline)
                }
                continue
            }

            // adaptive quiet floor
            if (amp < baseline * 1.4) baseline = baseline * 0.995 + amp * 0.005
            val ratio = amp / max(baseline, 0.0001)
            val level = soundLevel(amp)
            val elapsed = (now - startMs) / 1000.0

            // downsampled ~1s sample for the timeline
            if (lastSampleMs == 0L || now - lastSampleMs > 1000) {
                lastSampleMs = now
                NocturnePlugin.emitSample(elapsed, amp, level)
            }

            // smart alarm: within the wake window, fire at a light-sleep moment;
            // at the hard deadline, fire regardless.
            if (alarmEnabled && !alarmFired) {
                recentLevels.addLast(level)
                while (recentLevels.size > 30) recentLevels.removeFirst()  // ~30 reads window
                val past = System.currentTimeMillis()
                if (past >= alarmDeadlineMs) {
                    triggerAlarm()
                } else if (past >= alarmWindowStartMs && isLightSleepNow()) {
                    triggerAlarm()
                }
            }

            val snoreRatio = sensitivityRatio
            if (ratio > snoreRatio) {
                if (!epActive) {
                    epActive = true; epStartMs = now; epLastActiveMs = now; epPeak = level
                    epClip = ArrayList(clipSampleRate * 4)   // start a fresh clip buffer
                    epClf.reset(); frameBuf.clear()          // fresh acoustic analysis
                } else {
                    epLastActiveMs = now
                    if (level > epPeak) epPeak = level
                }
            }
            // while an episode is open, accumulate its audio (capped) + analyse frames
            val clip = epClip
            if (epActive && clip != null && clip.size < clipMaxSamples) {
                val room = clipMaxSamples - clip.size
                val n = min(read, room)
                for (i in 0 until n) clip.add(buffer[i])
            }
            if (epActive) {
                // decimate this chunk and consume full FFT frames for classification
                decimRate = AcousticFeatures.decimateInto(buffer, read, frameBuf, sampleRate)
                while (frameBuf.size >= AcousticFeatures.FRAME_FFT) {
                    for (i in 0 until AcousticFeatures.FRAME_FFT) analysisFrame[i] = frameBuf[i]
                    // drop the consumed frame in one shift (not one element at a time)
                    frameBuf.subList(0, AcousticFeatures.FRAME_FFT).clear()
                    AcousticFeatures.analyzeFrame(analysisFrame, decimRate, frameFeat)
                    epClf.add(frameFeat)
                }
            }
            // finalize an open episode only after continuous quiet beyond the merge gap
            if (epActive && (now - epLastActiveMs) >= snoreMergeGapMs) {
                finalizeEpisode()
            }

            // breathing-pause / apnea flag — near-TOTAL silence (well below breathing
            // sounds), 9-60s long, following a genuine snore episode (>=2s). Measured
            // when sound resumes so the recorded duration is the real gap length.
            // Quiet breathing stays above the silence floor and no longer counts.
            val silent = amp < baseline * 1.2
            if (silent) {
                if (silentSinceMs == 0L) silentSinceMs = now
            } else {
                if (silentSinceMs != 0L) {
                    val gap = (now - silentSinceMs) / 1000.0
                    val sinceEp = if (lastEpLoudMs != 0L) (silentSinceMs - lastEpLoudMs) / 1000.0 else Double.MAX_VALUE
                    if (gap in 9.0..60.0 && lastEpDurSec >= 2.0 && sinceEp in -2.0..20.0) {
                        pauseCount++
                        NocturnePlugin.emitPause((silentSinceMs - startMs) / 1000.0, gap, pauseCount)
                    }
                    silentSinceMs = 0L
                }
            }

            NocturnePlugin.emitLevel(level, ratio > snoreRatio, elapsed)
        }

        // flush a snore episode still open when recording stops
        if (epActive) {
            finalizeEpisode()
        }
        // flush a pause still open at stop (silence continued to the end)
        if (silentSinceMs != 0L) {
            val gap = (System.currentTimeMillis() - silentSinceMs) / 1000.0
            val sinceEp = if (lastEpLoudMs != 0L) (silentSinceMs - lastEpLoudMs) / 1000.0 else Double.MAX_VALUE
            if (gap in 9.0..60.0 && lastEpDurSec >= 2.0 && sinceEp in -2.0..20.0) {
                pauseCount++
                NocturnePlugin.emitPause((silentSinceMs - startMs) / 1000.0, gap, pauseCount)
            }
            silentSinceMs = 0L
        }

        try { recorder.stop() } catch (_: Exception) {}
        recorder.release()
    }

    /**
     * Close the open episode: classify it acoustically and emit the right event.
     * Snores keep the full treatment (count, audio clip, apnea context); movement and
     * other sounds are reported separately so sleep staging can use them without
     * polluting the snore statistics.
     */
    private fun finalizeEpisode() {
        val durSec = (epLastActiveMs - epStartMs) / 1000.0
        if (durSec > 0.35 && epPeak >= minEpisodePeak) {
            val kind = if (epClf.frameCount > 0) epClf.classify() else "other"
            if (kind == "snore") {
                snoreCount++
                val path = writeClip(epClip, snoreCount)
                NocturnePlugin.emitSnore((epStartMs - startMs) / 1000.0, durSec, epPeak, snoreCount, path)
                // remember as apnea context for pause detection (snores only)
                lastEpLoudMs = epLastActiveMs; lastEpDurSec = durSec
            } else {
                if (kind == "movement") movementCount++ else otherCount++
                NocturnePlugin.emitSound((epStartMs - startMs) / 1000.0, durSec, epPeak, kind,
                    if (kind == "movement") movementCount else otherCount)
            }
        }
        epActive = false; epClip = null
        epClf.reset(); frameBuf.clear()
    }

    private fun rms(buf: ShortArray, len: Int): Double {
        var sum = 0.0
        for (i in 0 until len) {
            val v = buf[i] / 32768.0
            sum += v * v
        }
        return sqrt(sum / len)
    }

    private fun soundLevel(amp: Double): Int {
        val b = if (baseline > 0) baseline else 0.01
        val ratio = max(1.0, amp / b)
        val lvl = log2(ratio) / log2(14.0) * 100.0
        return max(0.0, min(100.0, lvl)).toInt()
    }

    /** Compute the absolute wake window [start, deadline] from an HH:MM target + window minutes. */
    private fun computeAlarmWindow(hhmm: String, windowMin: Int) {
        val parts = hhmm.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: 7
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        // if the target time has already passed today, schedule for tomorrow
        if (cal.timeInMillis <= System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
        alarmDeadlineMs = cal.timeInMillis
        alarmWindowStartMs = alarmDeadlineMs - windowMin * 60_000L
    }

    /** Light sleep proxy: recent movement/restlessness is elevated (higher level variance),
     *  which correlates acoustically with lighter sleep — a good moment to wake. */
    private fun isLightSleepNow(): Boolean {
        if (recentLevels.size < 15) return false
        val mean = recentLevels.average()
        val variance = recentLevels.map { (it - mean) * (it - mean) }.average()
        val sd = sqrt(variance)
        // restless/light if there's audible movement variability or a raised mean level
        return sd > 7.0 || mean > 12.0
    }

    private fun triggerAlarm() {
        alarmFired = true
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                ALARM_CHANNEL_ID, "Smart alarm",
                NotificationManager.IMPORTANCE_HIGH
            )
            val alarmUri: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            ch.setSound(alarmUri, attrs)
            ch.enableVibration(true)
            nm.createNotificationChannel(ch)
        }
        val notif = NotificationCompat.Builder(this, ALARM_CHANNEL_ID)
            .setContentTitle("Good morning")
            .setContentText("Nocturne woke you at a light-sleep moment")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            .build()
        nm.notify(ALARM_NOTIF_ID, notif)
        // vibrate
        try {
            val vib = getSystemService(Vibrator::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 300, 500, 300, 500), -1))
            } else {
                @Suppress("DEPRECATION") vib.vibrate(longArrayOf(0, 500, 300, 500, 300, 500), -1)
            }
        } catch (_: Exception) {}
        NocturnePlugin.emitAlarm()
    }

    /** Write an episode's PCM samples to a 16-bit mono WAV file; returns its absolute path or "". */
    private fun writeClip(samples: ArrayList<Short>?, index: Int): String {
        if (samples == null || samples.isEmpty()) return ""
        val dir = clipsDir ?: return ""
        return try {
            val file = File(dir, "snore_${System.currentTimeMillis()}_$index.wav")
            val dataBytes = samples.size * 2
            val fos = FileOutputStream(file)
            // WAV header (44 bytes) + PCM
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray())
            header.putInt(36 + dataBytes)
            header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray())
            header.putInt(16)                 // subchunk1 size
            header.putShort(1)                // PCM
            header.putShort(1)                // mono
            header.putInt(clipSampleRate)
            header.putInt(clipSampleRate * 2) // byte rate (sampleRate * channels * bytesPerSample)
            header.putShort(2)                // block align
            header.putShort(16)               // bits per sample
            header.put("data".toByteArray())
            header.putInt(dataBytes)
            fos.write(header.array())
            // PCM body
            val body = ByteBuffer.allocate(dataBytes).order(ByteOrder.LITTLE_ENDIAN)
            for (s in samples) body.putShort(s)
            fos.write(body.array())
            fos.flush(); fos.close()
            file.absolutePath
        } catch (e: Exception) {
            ""
        }
    }
}
